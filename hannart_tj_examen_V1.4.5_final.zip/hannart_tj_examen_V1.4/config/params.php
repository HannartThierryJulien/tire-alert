<?php

return array (
  'adminEmail' => 'admin@example.com',
  'senderEmail' => 'noreply@example.com',
  'senderName' => 'Example.com mailer',
  'openWeatherMapAPI' => 'e03bf6231fc5c1f79985f0a90c9f619e',
  'googleGeocodeAPI' => 'AIzaSyCjPVbf6M_gVWok3szo50bWjKCc7oB2PKc',
);
